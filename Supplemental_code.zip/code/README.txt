Supplemental code for "Real Classical Waves in Quantum Configuration Space"

Requirements: Python 3, numpy, scipy, matplotlib.
Each script reproduces one figure (PDF and PNG) and prints the numerical values quoted in Sec. VIII:

  fig1_identity.py     Fig. 1  key identity H_t u = -Omega^{-1} d_t u, energy isometry, J and E conservation
  fig2_schrodinger.py  Fig. 2  Schrodinger limit, error bound, mode frequencies, real-wave reconstruction
  fig3_config.py       Fig. 3  two-quantum configuration space, multi-time UQM pair, sum/difference frequencies
  fig4_nonlinear.py    Fig. 4  cubic Klein-Gordon vs nonlinear Schrodinger, Duffing shift, orientation leakage
  fig5_meanfield.py    Fig. 5  coupled real oscillators vs mean field vs exact N-quantum dynamics

common.py holds the plotting style. Units: hbar = c = 1. Run, e.g.:  python3 fig1_identity.py
